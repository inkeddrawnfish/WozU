"use strict";
var somethingFun = "Riding my bike is fun!";
console.log(somethingFun);
