const sandwich: string = 'BLT';
const orderNumber: number = 1738;
const delicious: boolean = true;

function orderFood (sandwich, orderNumber) {
    console.log ('Your order number is ' + orderNumber + ' and contains a ' +  sandwich)
}

orderFood()