interface Person {
    firstName: string[];
    lastName?: string[];
}

interface Contact {
    phoneNumber: number;
    email?: string[];
}

class ContactCard implements Person, Contact {
    firstName: string[];
    phoneNumber: number;
    
    constructor(firstName: string, phoneNumber: number){
    }

    sendMessage(): any {
        console.log('Name: ' + firstName + ', Phone Number: ' + phoneNumber );
    }
}

const NewPerson = new ContactCard ('Henry', 1234567890)

NewPerson.sendMessage();