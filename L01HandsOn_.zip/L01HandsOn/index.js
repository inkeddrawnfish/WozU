"use strict";
var ContactCard = /** @class */ (function () {
    function ContactCard() {
    }
    ContactCard.prototype.sendMessage = function () {
        consol.log(this.firstName + phoneNumber);
    };
    return ContactCard;
}());
var NewPerson = new ContactCard('Henry', 1234567890);
NewPerson.sendMessage();
