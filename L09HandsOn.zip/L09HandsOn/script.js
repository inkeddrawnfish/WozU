function einstein() {
    
    let newRequest = new XMLHttpRequest();
    newRequest.onreadystatechange = function("einstein") {
      if (this.readyState == 4 && this.status == 200) {
        let myObj = JSON.parse(this.responseText);
        document.getElementById("bio").innerHTML = myObj.name;
      }
    };
    newRequest.open("GET", "https://www.nobelprize.org/prizes/physics/1921/einstein/biographical/", true);
    newRequest.send();
    
}

object.addEventListener("click",einstein);