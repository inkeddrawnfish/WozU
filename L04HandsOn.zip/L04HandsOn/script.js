class Employee {
    constructor(name, salary, hireDate) {
      this.name = name;
      this.salary = salary;
      this.hireDate = hireDate;
    }
    getName() {
      console.log(this.name.toUpperCase());
    }
    getSalary() {
      console.log(this.salary);
    }
    getHireDate() {
      console.log(this.hireDate);
    }
  }
class Manager extends Employee {
    constructor (descriptionOfJob, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.descriptionOfJob = descriptionOfJob;
        }
    jobDescription() {
        console.log (this.name+" was hired on "+this.hireDate+" and makes "+this.salary+" because they have "+this.descriptionOfJob);
}
}
class Designer extends Employee {
    constructor (experience, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.experience = experience;
    }
    yearsExperience(){
        console.log (this.name+" was hired on "+this.hireDate+" and makes "+this.salary+" because they have "+this.experience);
    }
}
class SalesAssociate extends Employee {
    constructor (degrees, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.degrees = degrees;
    }
    degreeCompleted() {
        console.log (this.name+" was hired on "+this.hireDate+" and makes "+this.salary+" because they have "+this.degrees);
    }
}
let management = new Manager("Project Management","Amber Jade Gallegos","$65,000","12/22/2017");
management.jobDescription();

let design = new Designer("Web Designer","Josh Butler","$90,000","4/17/2008");
design.yearsExperience();

let sales = new SalesAssociate("Recruiter","Donna Lee Cordova","$74,000","8/20/1995");
sales.degreeCompleted();