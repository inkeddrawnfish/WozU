import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';

const routes: Routes = [
    // you'll need a path for selecting the city
    // you'll need a path for the weather for a specific city
    // for root, add a redirect to the city path
];

// Don't forget your `RouterModule`!

@NgModule({
  imports: [],
  exports: []
})
export class AppRoutingModule { }
