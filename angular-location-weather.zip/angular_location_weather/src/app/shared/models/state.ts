export class State {
	id: number;
	name: string;
	country_id: number;
}
