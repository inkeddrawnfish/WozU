export class Country {
    id: number;
    sortname: string;
    name: string;
    phonecode: string;
}
