function regexChecker() {
    var myButton = document.getElementById("submitButton");
    var firstName = document.getElementById("firstName").innerHTML;
        newFunction();
    var lastName = document.getElementById("lastName").innerHTML;
        newFunction2();

    function newFunction() {
        console.log().test(/[A-Z]/);
    }
    function newFunction2() {
        console.log().test(/[A-Z]/);
    }
    
}

